This game is currently unsupported.  
These files are here just for future reference if support is ever added.