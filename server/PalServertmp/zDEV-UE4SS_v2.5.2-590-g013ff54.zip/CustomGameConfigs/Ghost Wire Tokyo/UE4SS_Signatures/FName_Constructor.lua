function Register()
    return "48 89 5C 24 10 48 89 74 24 18 57 48 81 EC 40 04 00 00"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end