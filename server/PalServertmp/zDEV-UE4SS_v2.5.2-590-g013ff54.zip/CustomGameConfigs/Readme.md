These settings are for games that have altered the engine in ways that make UE4SS not work out of the box.  
The folder structure in each game folder is the same as the regular UE4SS structure, meaning that files in the root directory go in the UE4SS root directory.
