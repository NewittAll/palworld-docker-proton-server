function Register()
    return "41 56 56 57 55 53 48 81 EC A0 01 00 00 48 89 CF"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end