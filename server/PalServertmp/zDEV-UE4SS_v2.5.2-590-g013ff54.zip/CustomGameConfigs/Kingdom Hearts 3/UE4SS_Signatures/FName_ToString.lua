function Register()
    return "4 8/8 9/5 C/2 4/0 8/4 8/8 9/7 4/2 4/1 0/4 8/8 9/7 C/2 4/1 8/4 1/5 6/4 8/8 3/E C/2 0/4 8/8 B/D A/4 C/8 B/F 1/? ?/? ?/? ?/? ?/? ?/4 C/8 B/C 8/4 1/8 B/0 6/9 9"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end